from django.shortcuts import render
from .yolov5.detect import run


def upload_file(request):
    if request.method == 'POST' and request.FILES['file']:
        file = request.FILES['file']
        # Perform the desired operations with the file
        # For example, you can save it to a specific location

        with open('object_detection/images_directory/' + file.name, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
        # You can also pass the file path to the context and render a response
        file_path = 'object_detection/images_directory/' + file.name
        print(file.name,"@@@@@@@@@@@@@@@")
        pred =run(weights="object_detection/yolov5/runs/train/exp5/weights/best.pt",source=file_path,)

        error = "false"
        try:
            result_class = pred[0]
        except Exception as e:
            print("%%%%%%%%%%%%%%%%%%%7677788",e)
            error =e
            result_class = "NONE"
        # score = pred[0][1]
        # with open("/home/indianic/PycharmProjects/ASL_YOLOV5/object_detection/static/labels/j_test.txt","r") as file:
        #     data = file.readlines()
        #     print(data)
        global is_video
        if file:
            file_ext = file.name.split('.')[-1].lower()
            if file_ext in ['jpg', 'jpeg', 'png', 'gif']:
                is_video = False
            elif file_ext in ['mp4', 'avi', 'mov']:
                is_video = True

            else:
                error = 'Invalid file type. Please upload an image or a video.'
                result_class = None
                is_video = False
        print(file.name)
        return render(request, 'upload_success.html', {'file_path': f"{file.name}","result_class" : result_class, "Error" : str(error),"is_video":is_video })
    return render(request, 'detect_objects.html')
# def upload_file(request):
#     if request.method == 'POST':
#         file = request.FILES.get('file')
#         if file:
#             file_ext = file.name.split('.')[-1].lower()
#             if file_ext in ['jpg', 'jpeg', 'png', 'gif']:
#                 file_path = process_image_file(file)
#                 result_class, error = detect_objects(file_path)
#                 is_video = False
#             elif file_ext in ['mp4', 'avi', 'mov']:
#                 file_path = process_video_file(file)
#                 result_class, error = detect_objects_from_video(file_path)
#                 is_video = True
#             else:
#                 error = 'Invalid file type. Please upload an image or a video.'
#                 result_class = None
#                 is_video = False
#
#             return render(request, 'upload_success.html', {'file_path': f"{file.name}", "result_class": result_class, "error": str(error), "is_video": is_video})
#     return render(request, 'detect_objects.html')
#
#
# def process_image_file(file):
#     file_path = 'object_detection/images_directory/' + file.name
#     with open(file_path, 'wb+') as destination:
#         for chunk in file.chunks():
#             destination.write(chunk)
#     return file_path
#
# def process_video_file(file):
#     file_path = 'object_detection/videos_directory/' + file.name
#     with open(file_path, 'wb+') as destination:
#         for chunk in file.chunks():
#             destination.write(chunk)
#     return file_path
#
# def detect_objects(file_path):
#     pred = run(weights="object_detection/yolov5/runs/train/exp5/weights/best.pt", source=file_path)
#
#     try:
#         result_class = pred[0]
#         error = False
#     except Exception as e:
#         result_class = "NONE"
#         error = str(e)
#
#     return result_class, error
#
# def detect_objects_from_video(file_path):
#     # Implement your video processing logic here using the file_path
#     # You can use libraries like OpenCV to read and process the video frames
#     # Apply object detection on each frame using yolov5.detect.run() or a similar function
#     # Return the final result_class and error message (if any)
#     pred = run(weights="object_detection/yolov5/runs/train/exp5/weights/best.pt", source=file_path)
#
#     try:
#         result_class = pred[0]
#         error = False
#     except Exception as e:
#         result_class = "NONE"
#         error = str(e)
#
#     return result_class, error
#
#     # Example implementation:
#     result_class = "Video detection not implemented yet"
#     error = "Video detection is currently not supported"
#     return result_class, error
